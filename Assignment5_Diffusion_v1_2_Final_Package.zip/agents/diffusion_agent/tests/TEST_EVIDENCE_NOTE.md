# Test evidence and version note

- The four response JSON files in `responses/` are byte-for-byte copies of the actual preserved runs. They were **not** edited to fix version labels, conclusions, citations, or wording.
- Baseline v1.1 assigned a provisional early-adopter stage to the pharma MR&I application without representative sustained-use evidence.
- The v1.2 primary response abstained from assigning the application stage. Contrast A and Contrast B also abstained, while distinguishing organizational readiness and bounded timing.
- The original revised/contrast outputs still report `agent.version = 1.1-student-2026-10-26`, because the metadata in the prompt-generation package had not been updated. This is a traceability defect, not evidence of a new post-correction run.
- The active `agent_metadata.json` now identifies v1.2 for **future** prompt generation. The existing response JSON files and original prompt texts remain unchanged.
- Source selection varied across runs. Similar diffusion conclusions are not evidence that identical citations or retrieval paths were used.
- The structural validator checks fields/types, not factual truth, source verification, policy adherence, or actual execution history.
- The `cases/contrast_1.json` and `cases/contrast_2.json` supplied in the working scaffold may differ from the specifically run Contrast A/B inputs; exact run inputs are separately saved under `tests/`.
- The original professor scaffold is in the supplied course ZIP. The original top-level `PACKAGE_SHA256.txt` is inherited from that scaffold and **is not a digest of this modified student package**.
